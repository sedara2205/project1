package com.mygdx.game.data;


public enum Direction {
    IDLE, UP, DOWN, LEFT, RIGHT
}

